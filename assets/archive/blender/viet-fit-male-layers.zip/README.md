# Asset nhân vật nam và trang phục rời

Tạo bằng công cụ image generation tích hợp. Mỗi PNG 1024 × 1536 có kênh alpha.

- `base.png`: nhân vật nam nền, mặc áo sát nách và quần ngắn, có giày.
- `ao-dai-navy.png`: áo dài xanh navy thêu rồng vàng.
- `ao-dai-burgundy.png`: áo dài đỏ thêu rồng vàng.
- `ao-dai-teal.png`: áo dài xanh ngọc thêu sen vàng.
- `trousers-ivory.png`: quần dài trắng ngà dùng chung.

Chạy frontend và mở `/male-studio`, hoặc chọn **Studio nam 3D** trên menu.
Chọn áo và quần trong hai nhóm riêng, sau đó tải PNG. Đổi áo giữ nguyên quần;
có thể dùng áo nền hoặc quần nền để bỏ riêng từng lớp. Lựa chọn được nhớ
trên trình duyệt; các lựa chọn bộ cũ được chuyển sang định dạng hai món.
Đường dẫn preview cũ chuyển sang Studio.

Thứ tự ghép: nhân vật nền → quần → áo. Dùng toàn bộ canvas, không cắt sát
biên asset. Các phép căn trong `catalog.json` và lưới nắn vai/cổ tay trong
`src/utils/renderMaleCharacter.ts` được dùng chung cho preview và PNG xuất ra,
không có thao tác kéo/chỉnh dành cho người dùng. Để chỉnh preset,
cập nhật `x`, `y`, `sx`, `sy` tại catalog; `x` là độ dịch ngang so với giữa canvas,
`y` là vị trí trên cùng, `sx`/`sy` là hệ số kích thước so với canvas gốc.
Lưới nắn giữ cổ và tà áo, nâng đường vai và đưa tay áo vào cổ tay nhân vật.
Các asset là ảnh raster phong cách 3D, chưa phải mesh, rig hoặc file Blender.
Chưa thay thế các lớp SVG của Studio hiện có.
